package com.handloom.handloom_platform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HandloomPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
