package com.handloom.handloom_platform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HandloomPlatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(HandloomPlatformApplication.class, args);
	}

}
